
package pos;

import view.Login;


public class POS {

    
    public static void main(String[] args) {
       
        Login l=new Login();
       // l.setUndecorated(true);
        l.setVisible(true);
        
        
    }
    
}
